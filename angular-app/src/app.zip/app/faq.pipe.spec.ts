import { FaqPipe } from './faq.pipe';

describe('FaqPipe', () => {
  it('create an instance', () => {
    const pipe = new FaqPipe();
    expect(pipe).toBeTruthy();
  });
});
