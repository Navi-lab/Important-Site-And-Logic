import { TempanswerPipe } from './tempanswer.pipe';

describe('TempanswerPipe', () => {
  it('create an instance', () => {
    const pipe = new TempanswerPipe();
    expect(pipe).toBeTruthy();
  });
});
