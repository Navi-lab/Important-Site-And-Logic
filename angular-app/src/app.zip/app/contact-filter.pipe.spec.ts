import { ContactFilterPipe } from './contact-filter.pipe';

describe('ContactFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ContactFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
