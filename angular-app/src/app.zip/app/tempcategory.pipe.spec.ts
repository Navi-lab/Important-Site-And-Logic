import { TempcategoryPipe } from './tempcategory.pipe';

describe('TempcategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new TempcategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
