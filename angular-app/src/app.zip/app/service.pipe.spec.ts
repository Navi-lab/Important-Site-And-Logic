import { ServicePipe } from './service.pipe';

describe('ServicePipe', () => {
  it('create an instance', () => {
    const pipe = new ServicePipe();
    expect(pipe).toBeTruthy();
  });
});
