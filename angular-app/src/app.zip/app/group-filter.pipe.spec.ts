import { GroupFilterPipe } from './group-filter.pipe';

describe('GroupFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GroupFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
