import { TemplatePipe } from './template.pipe';

describe('TemplatePipe', () => {
  it('create an instance', () => {
    const pipe = new TemplatePipe();
    expect(pipe).toBeTruthy();
  });
});
